public class OfficeEmployee extends Employee {
    private double overtimeHours;  // Số giờ làm thêm
    private double overtimeRate;   // Hệ số lương làm thêm

    // Constructor
    public OfficeEmployee(String name, String id, double salary, double overtimeHours, double overtimeRate) {
        super(name, id, salary);  // Gọi constructor của lớp cha
        this.overtimeHours = overtimeHours;
        this.overtimeRate = overtimeRate;
    }

    @Override
    public double calculateSalary() {
        return getSalary() + (overtimeHours * overtimeRate);  // Lương cơ bản + giờ làm thêm * hệ số
    }
}
