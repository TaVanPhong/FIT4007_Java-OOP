public abstract class Employee {
    private String name;   // Tên nhân viên
    private String id;     // Mã nhân viên
    private double salary; // Lương cơ bản

    // Constructor
    public Employee(String name, String id, double salary) {
        this.name = name;
        this.id = id;
        this.salary = salary;
    }

    // Phương thức abstract để tính lương
    public abstract double calculateSalary();

    // Phương thức hiển thị thông tin nhân viên
    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("ID: " + id);
        System.out.println("Base Salary: " + salary);
    }

    // Getters cho các thuộc tính
    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public double getSalary() {
        return salary;
    }
}
