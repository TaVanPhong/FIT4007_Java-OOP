import java.util.ArrayList;

public class EmployeeManagement {
    public static void main(String[] args) {
        // Khởi tạo danh sách nhân viên
        ArrayList<Employee> employeeList = new ArrayList<>();

        // Thêm các nhân viên thuộc các loại khác nhau vào danh sách
        employeeList.add(new OfficeEmployee("Nguyen Van A", "001", 3000, 10, 50)); // Nhân viên văn phòng
        employeeList.add(new ProductionEmployee("Le Thi B", "002", 2500, 200, 10)); // Nhân viên sản xuất
        employeeList.add(new Manager("Tran Van C", "003", 5000, 1500)); // Quản lý

        // Duyệt qua danh sách và hiển thị thông tin, lương của từng nhân viên
        for (Employee emp : employeeList) {
            emp.displayInfo();
            System.out.println("Total Salary: " + emp.calculateSalary());
            System.out.println("---------------------------------");
        }
    }
}
