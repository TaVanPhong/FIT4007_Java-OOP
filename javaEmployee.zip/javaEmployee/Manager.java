public class Manager extends Employee {
    private double responsibilityAllowance;  // Trợ cấp trách nhiệm

    // Constructor
    public Manager(String name, String id, double salary, double responsibilityAllowance) {
        super(name, id, salary);  // Gọi constructor của lớp cha
        this.responsibilityAllowance = responsibilityAllowance;
    }

    @Override
    public double calculateSalary() {
        return getSalary() + responsibilityAllowance;  // Lương = lương cơ bản + trợ cấp trách nhiệm
    }
}
